"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import { ArrowLeft, ArrowRight, Calculator, Eye, EyeOff, Lock, RotateCw, Search } from "lucide-react";
import { PROXY_PREFIX, toProxyUrl, utf8SafeDecode, utf8SafeEncode } from "@/lib/proxy-shared";
import { normalizeUrl } from "@/lib/urls";
import { scrambleUrl } from "@/lib/scramble";

interface BrowserShellProps {
  initialTarget: string;
}

/**
 * Deterministic navigation stack. The iframe's own joint history is unreliable
 * for driving chrome buttons (it mixes top-level and frame entries), so the
 * shell owns the stack: in-page link clicks are detected on iframe load and
 * pushed; back/forward set the iframe source directly.
 */
export default function BrowserShell({ initialTarget }: BrowserShellProps) {
  const router = useRouter();
  const iframeRef = useRef<HTMLIFrameElement>(null);

  const [stack, setStack] = useState<string[]>([initialTarget]);
  const [index, setIndex] = useState(0);
  const [urlText, setUrlText] = useState(initialTarget);
  const [loading, setLoading] = useState(true);
  const [frameKey, setFrameKey] = useState(0);
  const [revealed, setRevealed] = useState(false);
  const [editing, setEditing] = useState(false);

  const stackRef = useRef(stack);
  const indexRef = useRef(index);

  const target = stack[index] ?? "";

  // Load a target into the viewport at a given stack position.
  // NOTE: uses native history.replaceState — router.replace would re-mount the
  // dynamic route segment (keyed by the encoded URL param) and wipe our stack.
  const loadAt = useCallback((nextStack: string[], nextIndex: number) => {
    stackRef.current = nextStack;
    indexRef.current = nextIndex;
    setStack(nextStack);
    setIndex(nextIndex);
    setUrlText(nextStack[nextIndex]);
    setLoading(true);
    setFrameKey((k) => k + 1);
    window.history.replaceState(null, "", `/browse/${utf8SafeEncode(nextStack[nextIndex])}`);
  }, []);

  const navigate = useCallback(
    (raw: string) => {
      const next = normalizeUrl(raw);
      loadAt([...stack.slice(0, index + 1), next], index + 1);
    },
    [index, loadAt, stack],
  );

  const goBack = useCallback(() => {
    if (index > 0) loadAt(stack, index - 1);
  }, [index, loadAt, stack]);

  const goForward = useCallback(() => {
    if (index < stack.length - 1) loadAt(stack, index + 1);
  }, [index, loadAt, stack]);

  const refresh = useCallback(() => {
    setLoading(true);
    setFrameKey((k) => k + 1);
  }, []);

  // Exit: unmount the iframe first so active streams die immediately,
  // wipe local state, then replace the history entry so "back" won't return here.
  const exitToCalculator = useCallback(() => {
    setStack([]);
    setIndex(0);
    setUrlText("");
    setLoading(false);
    router.replace("/");
  }, [router]);

  // Fires on every iframe navigation (initial load, link clicks, form posts).
  const onIframeLoad = useCallback(() => {
    setLoading(false);
    let decoded: string | null = null;
    try {
      const win = iframeRef.current?.contentWindow;
      if (!win) return;
      const path = win.location.pathname;
      if (!path.startsWith(PROXY_PREFIX)) return;
      decoded = utf8SafeDecode(path.slice(PROXY_PREFIX.length));
    } catch {
      return; // cross-origin shouldn't happen (proxy is same-origin)
    }
    if (!decoded) return;

    setUrlText(decoded);
    // In-page navigation (link click inside the site): push onto the stack
    // and sync the address bar without touching the Next router (see loadAt).
    if (decoded !== stackRef.current[indexRef.current]) {
      const nextStack = [...stackRef.current.slice(0, indexRef.current + 1), decoded];
      stackRef.current = nextStack;
      indexRef.current = nextStack.length - 1;
      setStack(nextStack);
      setIndex(nextStack.length - 1);
      window.history.replaceState(null, "", `/browse/${utf8SafeEncode(decoded)}`);
    }
  }, []);

  // Show a scrambled URL unless the user is editing or has toggled reveal.
  const displayUrl = editing || revealed ? urlText : scrambleUrl(urlText);

  if (!target) return null;

  return (
    <main className="flex h-dvh flex-col overflow-hidden bg-zinc-950">
      {/* Browser chrome */}
      <header className="flex h-14 shrink-0 items-center gap-1.5 border-b border-zinc-800 bg-zinc-900/90 px-2 backdrop-blur">
        <button
          onClick={goBack}
          disabled={index === 0}
          aria-label="Back"
          data-testid="button-back"
          className="flex h-9 w-9 items-center justify-center rounded-lg text-zinc-300 hover:bg-zinc-800 disabled:opacity-30"
        >
          <ArrowLeft className="h-5 w-5" />
        </button>
        <button
          onClick={goForward}
          disabled={index >= stack.length - 1}
          aria-label="Forward"
          data-testid="button-forward"
          className="flex h-9 w-9 items-center justify-center rounded-lg text-zinc-300 hover:bg-zinc-800 disabled:opacity-30"
        >
          <ArrowRight className="h-5 w-5" />
        </button>
        <button
          onClick={refresh}
          aria-label="Refresh"
          data-testid="button-refresh"
          className="flex h-9 w-9 items-center justify-center rounded-lg text-zinc-300 hover:bg-zinc-800"
        >
          <RotateCw className={`h-5 w-5 ${loading ? "animate-spin" : ""}`} />
        </button>

        {/* URL bar — scrambled at rest, plaintext while editing or revealed */}
        <form
          className="flex h-10 min-w-0 flex-1 items-center gap-2 rounded-xl border border-zinc-700/80 bg-zinc-950/80 px-3 focus-within:border-orange-500/60"
          onSubmit={(e) => {
            e.preventDefault();
            (e.currentTarget.querySelector("input") as HTMLInputElement | null)?.blur();
            if (urlText.trim()) navigate(urlText);
          }}
        >
          <Lock className="h-3.5 w-3.5 shrink-0 text-zinc-500" aria-label="Secure" />
          <input
            value={displayUrl}
            onChange={(e) => setUrlText(e.target.value)}
            onFocus={(e) => {
              setEditing(true);
              e.target.select();
            }}
            onBlur={() => {
              setEditing(false);
              setUrlText(target);
            }}
            onKeyDown={(e) => {
              if (e.key === "Escape") {
                (e.target as HTMLInputElement).blur();
              }
            }}
            spellCheck={false}
            autoComplete="off"
            aria-label="URL bar"
            data-testid="input-url"
            className="min-w-0 flex-1 bg-transparent text-sm text-zinc-200 placeholder-zinc-500 outline-none"
            placeholder="Search or enter address"
          />
          <button
            type="button"
            onClick={() => setRevealed((r) => !r)}
            aria-label={revealed ? "Hide URL" : "Reveal URL"}
            data-testid="button-reveal"
            className="shrink-0 text-zinc-500 hover:text-zinc-300"
          >
            {revealed ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
          </button>
          <button
            type="submit"
            aria-label="Go"
            data-testid="button-url-go"
            className="shrink-0 text-zinc-500 hover:text-orange-400"
          >
            <Search className="h-4 w-4" />
          </button>
        </form>

        <button
          onClick={exitToCalculator}
          aria-label="Exit to calculator"
          data-testid="button-exit"
          className="flex h-9 w-9 items-center justify-center rounded-lg text-zinc-300 hover:bg-zinc-800"
        >
          <Calculator className="h-5 w-5" />
        </button>
      </header>

      {/* Loading progress bar */}
      <div className={`h-0.5 shrink-0 overflow-hidden bg-zinc-800 ${loading ? "opacity-100" : "opacity-0"} transition-opacity`}>
        <div className="h-full w-1/3 animate-[loadingbar_1.2s_ease-in-out_infinite] bg-orange-500" />
      </div>

      {/* Viewport */}
      <div className="relative min-h-0 flex-1 bg-white">
        {target && (
          <iframe
            key={frameKey}
            ref={iframeRef}
            src={toProxyUrl(target)}
            onLoad={onIframeLoad}
            title="Browser viewport"
            data-testid="proxy-viewport"
            className="h-full w-full border-0 bg-white"
            // Sandbox blocks the framed site from navigating the TOP window
            // (frame-busting) while keeping scripts, forms, popups and storage.
            sandbox="allow-scripts allow-forms allow-popups allow-same-origin allow-downloads allow-presentation"
            allow="autoplay; fullscreen; clipboard-write; encrypted-media; picture-in-picture"
          />
        )}
        {loading && (
          <div className="pointer-events-none absolute inset-0 flex items-center justify-center bg-zinc-950/40 backdrop-blur-[2px]">
            <div className="h-8 w-8 animate-spin rounded-full border-2 border-zinc-600 border-t-orange-500" />
          </div>
        )}
      </div>

      <style jsx>{`
        @keyframes loadingbar {
          0% {
            transform: translateX(-100%);
          }
          50% {
            transform: translateX(150%);
          }
          100% {
            transform: translateX(-100%);
          }
        }
      `}</style>
    </main>
  );
}
