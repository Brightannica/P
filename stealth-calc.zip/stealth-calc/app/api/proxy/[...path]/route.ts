import { NextRequest, NextResponse } from "next/server";
import { utf8SafeDecode, toProxyUrl, PROXY_PREFIX } from "@/lib/proxy-shared";
import { rewriteHtml, rewriteCss, rewriteM3u8, type RewriteContext } from "@/lib/rewrite";

export const dynamic = "force-dynamic";
export const runtime = "nodejs";

// ---------------------------------------------------------------------------
// Constants
// ---------------------------------------------------------------------------

const DESKTOP_UA =
  "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36";

/** Proxied sites get their cookies namespaced so they can't clobber app cookies. */
const COOKIE_PREFIX = "__p_";

/** Response headers that break framing or leak proxy internals. */
const STRIP_RESPONSE_HEADERS = new Set([
  "x-frame-options",
  "content-security-policy",
  "content-security-policy-report-only",
  "cross-origin-opener-policy",
  "cross-origin-embedder-policy",
  "cross-origin-resource-policy",
  "strict-transport-security",
  "content-encoding",
  "transfer-encoding",
  "connection",
  "keep-alive",
  "report-to",
  "nel",
]);

/** Request headers that must never be forwarded verbatim. */
const STRIP_REQUEST_HEADERS = new Set(["host", "cookie", "accept-encoding", "x-forwarded-*"]);

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

interface TargetInfo {
  url: URL;
  encoded: string;
}

function parseTarget(pathSegments: string[]): TargetInfo | null {
  const encoded = pathSegments.join("/");
  if (!encoded) return null;
  let target: string;
  try {
    target = utf8SafeDecode(encoded);
  } catch {
    return null;
  }
  let url: URL;
  try {
    url = new URL(target);
  } catch {
    return null;
  }
  if (url.protocol !== "http:" && url.protocol !== "https:") return null;
  return { url, encoded };
}

/** Forward only cookies that belong to proxied sites (strip our __p_ prefix). */
function forwardedCookies(cookieHeader: string | null): string | null {
  if (!cookieHeader) return null;
  const kept = cookieHeader
    .split(";")
    .map((c) => c.trim())
    .filter(Boolean)
    .filter((c) => c.startsWith(COOKIE_PREFIX))
    .map((c) => c.slice(COOKIE_PREFIX.length));
  return kept.length ? kept.join("; ") : null;
}

/** Rewrite Set-Cookie headers so they live on the proxy origin, namespaced. */
function rewriteSetCookies(res: Response): string[] {
  const raw =
    typeof (res.headers as unknown as { getSetCookie?: () => string[] }).getSetCookie === "function"
      ? (res.headers as unknown as { getSetCookie: () => string[] }).getSetCookie()
      : res.headers.get("set-cookie")
        ? [res.headers.get("set-cookie")!]
        : [];
  const out: string[] = [];
  for (const line of raw) {
    const semi = line.indexOf(";");
    const [nameValue] = (semi === -1 ? line : line.slice(0, semi)).split("=");
    if (!nameValue) continue;
    const rest = semi === -1 ? "" : line.slice(semi + 1);
    const attrs = rest
      .split(";")
      .map((a) => a.trim())
      .filter(Boolean)
      .filter((a) => {
        const key = a.split("=")[0].toLowerCase();
        // Drop scoping attributes that would misapply the cookie.
        return key !== "domain" && key !== "secure" && key !== "samesite" && key !== "partitioned" && key !== "priority";
      })
      .filter((a) => {
        // Only keep attributes we understand: path, expires, max-age, httponly.
        const key = a.split("=")[0].toLowerCase();
        return ["path", "expires", "max-age", "httponly"].includes(key);
      });
    const parts = [`${COOKIE_PREFIX}${nameValue.trim()}=${(semi === -1 ? line : line.slice(0, semi)).split("=").slice(1).join("=")}`];
    if (!attrs.some((a) => a.toLowerCase().startsWith("path="))) parts.push("Path=/");
    out.push(parts.concat(attrs).join("; "));
  }
  return out;
}

function rewriteContext(base: string): RewriteContext {
  return { base, proxyPrefix: PROXY_PREFIX, toProxy: toProxyUrl };
}

function errorPage(title: string, detail: string, status: number): NextResponse {
  const html = `<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${title}</title><style>
  body{margin:0;min-height:100vh;display:flex;align-items:center;justify-content:center;background:#09090b;color:#e4e4e7;font:16px/1.6 system-ui,-apple-system,sans-serif}
  .card{max-width:420px;padding:40px;text-align:center}
  h1{font-size:20px;font-weight:600;margin:0 0 12px}
  p{margin:0;color:#a1a1aa;font-size:14px}
  code{color:#f97316;font-size:12px;word-break:break-all}
  </style></head><body><div class="card"><h1>${title}</h1><p>${detail}</p></div></body></html>`;
  return new NextResponse(html, { status, headers: { "content-type": "text/html; charset=utf-8", "cache-control": "no-store" } });
}

// ---------------------------------------------------------------------------
// Core proxy
// ---------------------------------------------------------------------------

async function proxyRequest(req: NextRequest, targetInfo: TargetInfo): Promise<NextResponse> {
  const { url: target } = targetInfo;

  // ---- Build outgoing headers -------------------------------------------
  const outHeaders = new Headers();
  req.headers.forEach((value, key) => {
    const lower = key.toLowerCase();
    if (STRIP_REQUEST_HEADERS.has(lower) || STRIP_REQUEST_HEADERS.has(lower.replace(/-[^-]+$/, "-*"))) return;
    if (lower === "cookie") return;
    if (lower === "referer" || lower === "origin" || lower === "user-agent") return;
    outHeaders.set(key, value);
  });
  const cookie = forwardedCookies(req.headers.get("cookie"));
  if (cookie) outHeaders.set("cookie", cookie);
  outHeaders.set("user-agent", DESKTOP_UA);
  outHeaders.set("referer", target.href);
  if (req.method !== "GET" && req.method !== "HEAD") {
    outHeaders.set("origin", target.origin);
  }

  // ---- Upstream request ---------------------------------------------------
  let upstream: Response;
  try {
    upstream = await fetch(target.href, {
      method: req.method === "HEAD" ? "GET" : req.method,
      headers: outHeaders,
      body: req.method === "GET" || req.method === "HEAD" ? undefined : req.body,
      redirect: "manual",
      // @ts-expect-error -- Node fetch requires duplex for streamed bodies
      duplex: req.method === "GET" || req.method === "HEAD" ? undefined : "half",
    });
  } catch (err) {
    const detail = err instanceof Error ? err.message : "Unknown error";
    return errorPage(
      "Site unreachable",
      `The proxy could not load <code>${target.href}</code>.<br>${detail}`,
      502,
    );
  }

  // ---- Redirects: keep them inside the proxy namespace --------------------
  const redirectStatuses = [301, 302, 303, 307, 308];
  const location = upstream.headers.get("location");
  if (redirectStatuses.includes(upstream.status) && location) {
    let abs: URL;
    try {
      abs = new URL(location, target.href);
    } catch {
      return errorPage("Bad redirect", `Invalid redirect target: <code>${location}</code>`, 502);
    }
    const redirectRes = new NextResponse(null, {
      status: redirectStatuses.includes(upstream.status) ? upstream.status : 302,
      headers: { location: toProxyUrl(abs.href) },
    });
    for (const c of rewriteSetCookies(upstream)) redirectRes.headers.append("set-cookie", c);
    redirectRes.headers.set("cache-control", "no-store");
    return redirectRes;
  }

  // ---- Build sanitized response headers -----------------------------------
  const contentType = upstream.headers.get("content-type") || "";
  const wasEncoded = Boolean(upstream.headers.get("content-encoding"));

  const resHeaders = new Headers();
  upstream.headers.forEach((value, key) => {
    const lower = key.toLowerCase();
    if (lower === "set-cookie") return;
    if (STRIP_RESPONSE_HEADERS.has(lower)) return;
    if (
      lower === "content-length" &&
      (wasEncoded ||
        (!contentType.startsWith("audio/") &&
          !contentType.startsWith("video/") &&
          !contentType.startsWith("image/") &&
          !contentType.startsWith("font/")))
    )
      return;
    resHeaders.set(key, value);
  });
  for (const c of rewriteSetCookies(upstream)) resHeaders.append("set-cookie", c);
  resHeaders.set("access-control-allow-origin", "*");

  // ---- Rewrite or stream ----------------------------------------------------
  const pathLower = target.pathname.toLowerCase();

  if (req.method === "HEAD") {
    return new NextResponse(null, { status: upstream.status, headers: resHeaders });
  }

  if (contentType.includes("text/html") || contentType.includes("xml")) {
    let body: string;
    try {
      body = await upstream.text();
    } catch {
      return errorPage("Read error", "Could not read the page body.", 502);
    }
    resHeaders.set("content-type", "text/html; charset=utf-8");
    resHeaders.set("cache-control", "no-store");
    const rewritten = rewriteHtml(body, rewriteContext(target.href));
    return new NextResponse(rewritten, { status: upstream.status, headers: resHeaders });
  }

  if (contentType.includes("text/css")) {
    let body: string;
    try {
      body = await upstream.text();
    } catch {
      return errorPage("Read error", "Could not read the stylesheet.", 502);
    }
    resHeaders.set("content-type", "text/css; charset=utf-8");
    resHeaders.set("cache-control", "no-store");
    return new NextResponse(rewriteCss(body, rewriteContext(target.href)), { status: upstream.status, headers: resHeaders });
  }

  const isHls =
    contentType.includes("mpegurl") ||
    contentType.includes("vnd.apple") ||
    pathLower.endsWith(".m3u8") ||
    pathLower.endsWith(".m3u");
  if (isHls) {
    let body: string;
    try {
      body = await upstream.text();
    } catch {
      return errorPage("Read error", "Could not read the playlist.", 502);
    }
    resHeaders.set("cache-control", "no-store");
    return new NextResponse(rewriteM3u8(body, rewriteContext(target.href)), { status: upstream.status, headers: resHeaders });
  }

  // Everything else: pass the body through untouched as a stream (video, audio,
  // images, fonts, JSON, downloads). Range requests keep working because the
  // Range header is forwarded and status + Content-Range are mirrored.
  resHeaders.set(
    "cache-control",
    /^(audio|video|image|font)\//.test(contentType) ? "public, max-age=3600" : "no-store",
  );
  return new NextResponse(upstream.body, { status: upstream.status, headers: resHeaders });
}

// ---------------------------------------------------------------------------
// Route handlers
// ---------------------------------------------------------------------------

type Ctx = { params: { path: string[] } };

async function handle(req: NextRequest, ctx: Ctx): Promise<NextResponse> {
  const targetInfo = parseTarget(ctx.params.path ?? []);
  if (!targetInfo) {
    return errorPage("Invalid proxy request", "This endpoint expects a base64url-encoded URL.", 400);
  }
  return proxyRequest(req, targetInfo);
}

export async function GET(req: NextRequest, ctx: Ctx) {
  return handle(req, ctx);
}
export async function HEAD(req: NextRequest, ctx: Ctx) {
  return handle(req, ctx);
}
export async function POST(req: NextRequest, ctx: Ctx) {
  return handle(req, ctx);
}
export async function PUT(req: NextRequest, ctx: Ctx) {
  return handle(req, ctx);
}
export async function PATCH(req: NextRequest, ctx: Ctx) {
  return handle(req, ctx);
}
export async function DELETE(req: NextRequest, ctx: Ctx) {
  return handle(req, ctx);
}

export async function OPTIONS() {
  return new NextResponse(null, {
    status: 204,
    headers: {
      "access-control-allow-origin": "*",
      "access-control-allow-methods": "GET, HEAD, POST, PUT, PATCH, DELETE, OPTIONS",
      "access-control-allow-headers": reqAllowHeaders(),
      "access-control-max-age": "86400",
    },
  });
}

function reqAllowHeaders(): string {
  return "content-type, range, accept, accept-language, cookie, authorization";
}
