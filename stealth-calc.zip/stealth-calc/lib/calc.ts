// Safe arithmetic expression evaluator (shunting-yard -> RPN).
// No eval/new Function: user input is never executed as code.

export interface EvalResult {
  ok: boolean;
  value?: number;
  error?: string;
}

type Tok = { kind: "num" | "op"; value?: number; op?: string };

const PRECEDENCE: Record<string, number> = {
  "u-": 4,
  "%": 3,
  "*": 2,
  "/": 2,
  "+": 1,
  "-": 1,
};
const RIGHT_ASSOC = new Set(["u-"]);

function tokenize(expr: string): Tok[] | null {
  const tokens: Tok[] = [];
  let i = 0;
  const s = expr.replace(/×/g, "*").replace(/÷/g, "/").replace(/,/g, "");
  const prevMeaningful = () => tokens[tokens.length - 1];

  while (i < s.length) {
    const c = s[i];
    if (c === " ") {
      i++;
      continue;
    }
    if (/[0-9.]/.test(c)) {
      let j = i;
      while (j < s.length && /[0-9.]/.test(s[j])) j++;
      const numStr = s.slice(i, j);
      if (!/^\d*\.?\d+$/.test(numStr) || (numStr.match(/\./g) || []).length > 1) return null;
      tokens.push({ kind: "num", value: parseFloat(numStr) });
      i = j;
      continue;
    }
    if (c === "(") {
      tokens.push({ kind: "op", op: "(" });
      i++;
      continue;
    }
    if (c === ")") {
      tokens.push({ kind: "op", op: ")" });
      i++;
      continue;
    }
    if ("+-*/%".includes(c)) {
      // Unary minus when at start, or after another operator / open paren.
      const prev = prevMeaningful();
      const isUnary = c === "-" && (!prev || (prev.kind === "op" && prev.op !== ")"));
      tokens.push({ kind: "op", op: isUnary ? "u-" : c });
      i++;
      continue;
    }
    return null; // any other character -> not a math expression
  }
  return tokens;
}

function precOf(tok: Tok): number {
  return PRECEDENCE[tok.op ?? ""] ?? -1;
}

function toRpn(tokens: Tok[]): Tok[] | null {
  const output: Tok[] = [];
  const stack: Tok[] = [];
  for (const tok of tokens) {
    if (tok.kind === "num") {
      output.push(tok);
      continue;
    }
    const op = tok.op;
    if (op === "(") {
      stack.push(tok);
    } else if (op === ")") {
      while (stack.length && stack[stack.length - 1].op !== "(") output.push(stack.pop()!);
      if (!stack.length) return null; // unbalanced
      stack.pop();
    } else {
      if (!op) return null;
      while (
        stack.length &&
        stack[stack.length - 1].op !== "(" &&
        (precOf(stack[stack.length - 1]) > PRECEDENCE[op] ||
          (precOf(stack[stack.length - 1]) === PRECEDENCE[op] && !RIGHT_ASSOC.has(op)))
      ) {
        output.push(stack.pop()!);
      }
      stack.push(tok);
    }
  }
  while (stack.length) {
    const top = stack.pop()!;
    if (top.op === "(") return null;
    output.push(top);
  }
  return output;
}

function evalRpn(rpn: Tok[]): number | null {
  const st: number[] = [];
  for (const tok of rpn) {
    if (tok.kind === "num") {
      st.push(tok.value!);
      continue;
    }
    const op = tok.op;
    if (!op) return null;
    if (op === "u-") {
      const a = st.pop();
      if (a === undefined) return null;
      st.push(-a);
      continue;
    }
    if (tok.op === "%") {
      const a = st.pop();
      if (a === undefined) return null;
      st.push(a / 100);
      continue;
    }
    const b = st.pop();
    const a = st.pop();
    if (a === undefined || b === undefined) return null;
    switch (tok.op) {
      case "+":
        st.push(a + b);
        break;
      case "-":
        st.push(a - b);
        break;
      case "*":
        st.push(a * b);
        break;
      case "/":
        if (b === 0) return null;
        st.push(a / b);
        break;
      default:
        return null;
    }
  }
  if (st.length !== 1) return null;
  return st[0];
}

export function formatNumber(n: number): string {
  if (!isFinite(n)) return "Error";
  const rounded = parseFloat(n.toPrecision(12));
  if (Object.is(rounded, -0)) return "0";
  return String(rounded);
}

export function evaluateExpression(expr: string): EvalResult {
  const trimmed = expr.trim();
  if (!trimmed) return { ok: false, error: "empty" };
  const tokens = tokenize(trimmed);
  if (!tokens) return { ok: false, error: "invalid" };
  const rpn = toRpn(tokens);
  if (!rpn) return { ok: false, error: "invalid" };
  const value = evalRpn(rpn);
  if (value === null || isNaN(value)) return { ok: false, error: "invalid" };
  return { ok: true, value };
}

/** True when the string is a complete, valid math expression. */
export function isMathExpression(expr: string): boolean {
  return evaluateExpression(expr).ok;
}
