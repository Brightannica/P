// Streaming-friendly rewriting of HTML / CSS / HLS playlists fetched through the proxy.
// Deliberately regex-based: no DOM parser dependency, works in the Node runtime,
// and handles the vast majority of real-world markup.

export interface RewriteContext {
  /** Absolute URL of the page/stylesheet being rewritten. */
  base: string;
  /** Same-origin prefix of the proxy, e.g. "/api/proxy/". */
  proxyPrefix: string;
  /** Function that turns an absolute URL into a proxy URL. */
  toProxy: (absolute: string) => string;
}

const SKIP_VALUE = /^(?:#|javascript:|data:|blob:|mailto:|tel:|about:|sms:|intent:|ws:|wss:|itms:)/i;

/** Decode common HTML entities that appear inside attribute values. */
function decodeEntities(v: string): string {
  const AMP = "&" + "amp;";
  return v
    .split(AMP).join("&")
    .split("&" + "lt;").join("<")
    .split("&" + "gt;").join(">")
    .split("&" + "quot;").join('"')
    .split("&#" + "39;").join("'")
    .split("&#" + "0" + "39;").join("'");
}

/** Resolve a possibly-relative URL against base; null when unusable. */
function absolutize(value: string, base: string): string | null {
  const v = decodeEntities(value).trim();
  if (!v || SKIP_VALUE.test(v)) return null;
  try {
    const u = new URL(v, base);
    if (u.protocol !== "http:" && u.protocol !== "https:") return null;
    return u.href;
  } catch {
    return null;
  }
}

const URL_ATTRS =
  "href|src|action|formaction|poster|data-src|data-href|data-url|data-background|background";

/**
 * Rewrite link-ish attributes in HTML fragments. Handles double-quoted,
 * single-quoted and unquoted values.
 */
function rewriteUrlAttributes(html: string, ctx: RewriteContext): string {
  const quoted = new RegExp(`(\\s(?:${URL_ATTRS})\\s*=\\s*)("([^"]*)"|'([^']*)')`, "gi");
  html = html.replace(quoted, (match, pre: string, _q: string, dq?: string, sq?: string) => {
    const value = dq !== undefined ? dq : sq ?? "";
    const abs = absolutize(value, ctx.base);
    if (!abs) return match;
    return `${pre}"${ctx.toProxy(abs)}"`;
  });

  const unquoted = new RegExp(`(\\s(?:${URL_ATTRS})\\s*=\\s*)([^\\s"'>]+)`, "gi");
  html = html.replace(unquoted, (match, pre: string, value: string) => {
    const abs = absolutize(value, ctx.base);
    if (!abs) return match;
    return `${pre}${ctx.toProxy(abs)}`;
  });
  return html;
}

/** Rewrite srcset="a.png 1x, b.png 2x" declarations. */
function rewriteSrcset(html: string, ctx: RewriteContext): string {
  return html.replace(/(\ssrcset\s*=\s*)("([^"]*)"|'([^']*)')/gi, (match, pre: string, _q: string, dq?: string, sq?: string) => {
    const value = dq !== undefined ? dq : sq ?? "";
    const rewritten = value
      .split(",")
      .map((part) => {
        const trimmed = part.trim();
        if (!trimmed) return "";
        const spaceIdx = trimmed.search(/\s/);
        const url = spaceIdx === -1 ? trimmed : trimmed.slice(0, spaceIdx);
        const descriptor = spaceIdx === -1 ? "" : trimmed.slice(spaceIdx);
        const abs = absolutize(url, ctx.base);
        return abs ? ctx.toProxy(abs) + descriptor : url + descriptor;
      })
      .filter(Boolean)
      .join(", ");
    return `${pre}"${rewritten}"`;
  });
}

/** Rewrite url(...) references and @import statements in CSS. */
export function rewriteCss(css: string, ctx: RewriteContext): string {
  css = css.replace(/url\(\s*(['"]?)([^'")]+)\1\s*\)/gi, (match, _q: string, value: string) => {
    const abs = absolutize(value, ctx.base);
    if (!abs) return match;
    return `url("${ctx.toProxy(abs)}")`;
  });
  css = css.replace(/@import\s+(['"])([^'"]+)\1/gi, (match, _q: string, value: string) => {
    const abs = absolutize(value, ctx.base);
    if (!abs) return match;
    return `@import "${ctx.toProxy(abs)}"`;
  });
  return css;
}

/** Rewrite inline style="... url(...) ..." attributes. */
function rewriteStyleAttrs(html: string, ctx: RewriteContext): string {
  return html.replace(/(\sstyle\s*=\s*)("([^"]*)"|'([^']*)')/gi, (match, pre: string, _q: string, dq?: string, sq?: string) => {
    const value = dq !== undefined ? dq : sq ?? "";
    const rewritten = rewriteCss(value, ctx);
    if (rewritten === value) return match;
    return `${pre}"${rewritten}"`;
  });
}

/** Strip CSP/CORP meta tags, <base> tags, integrity + crossorigin attributes. */
function stripSecurityMarkup(html: string): string {
  html = html.replace(/<meta[^>]+http-equiv\s*=\s*["']?content-security-policy[^>]*>/gi, "");
  html = html.replace(/<meta[^>]+http-equiv\s*=\s*["']?x-frame-options[^>]*>/gi, "");
  html = html.replace(/<base[^>]*>/gi, "");
  // Content is modified in flight, so subresource integrity hashes would fail.
  html = html.replace(/\sintegrity(?:\s*=\s*(?:"[^"]*"|'[^']*'|[^\s>]+))?/gi, "");
  html = html.replace(/\scrossorigin(?:\s*=\s*(?:"[^"]*"|'[^']*'|[^\s>]+))?/gi, "");
  return html;
}

/**
 * Client-side shim injected into rewritten pages. Patches fetch / XHR /
 * window.open so dynamically requested resources stay inside the proxy,
 * rewrites DOM nodes added at runtime, and neutralizes service workers
 * (a target-site SW must never take scope on the proxy origin).
 */
function buildClientShim(ctx: RewriteContext): string {
  const cfg = JSON.stringify({ target: ctx.base, prefix: ctx.proxyPrefix });
  return `<script data-proxy-shim>(function(){
var CFG = ${cfg};
var T = CFG.target, PREFIX = CFG.prefix;
function enc(u){
  try {
    var bytes = new TextEncoder().encode(u), bin = "";
    for (var i = 0; i < bytes.length; i++) bin += String.fromCharCode(bytes[i]);
    return btoa(bin).replace(/\\+/g, "-").replace(/\\//g, "_").replace(/=+$/, "");
  } catch (e) { return btoa(u); }
}
function isProxy(u){ return u.indexOf(PREFIX) === 0 || u.indexOf(location.origin + PREFIX) === 0; }
function toProxy(u){
  try {
    if (!u) return u;
    if (/^(data:|blob:|about:|javascript:|mailto:|tel:|#)/i.test(u)) return u;
    if (isProxy(u)) return u;
    var a = new URL(u, T);
    if (a.protocol !== "http:" && a.protocol !== "https:") return u;
    return PREFIX + enc(a.href);
  } catch (e) { return u; }
}
var _fetch = window.fetch;
window.fetch = function(input, init){
  try {
    if (typeof input === "string") { input = toProxy(input); }
    else if (input && typeof input.url === "string") { input = new Request(toProxy(input.url), input); }
  } catch (e) {}
  return _fetch.call(window, input, init);
};
var _open = XMLHttpRequest.prototype.open;
XMLHttpRequest.prototype.open = function(method, url){
  try { arguments[1] = toProxy(String(url)); } catch (e) {}
  return _open.apply(this, arguments);
};
var _winOpen = window.open;
window.open = function(u){
  try { if (u) arguments[0] = toProxy(String(u)); } catch (e) {}
  return _winOpen.apply(this, arguments);
};
if (navigator.serviceWorker) {
  navigator.serviceWorker.register = function(){ return Promise.reject(new Error("service workers disabled inside proxy")); };
}
var ATTRS = ["href", "src", "action", "poster", "srcset"];
function fixEl(el){
  if (!el || !el.getAttribute) return;
  for (var i = 0; i < ATTRS.length; i++) {
    var a = ATTRS[i];
    var v;
    try { v = el.getAttribute(a); } catch (e) { continue; }
    if (!v || v.indexOf(PREFIX) !== -1) continue;
    if (a === "srcset") {
      try { el.setAttribute(a, v.split(",").map(function(p){
        var t = p.trim().split(/\\s+/);
        t[0] = toProxy(t[0]);
        return t.join(" ");
      }).join(", ")); } catch (e) {}
      continue;
    }
    var nv = toProxy(v);
    if (nv !== v) { try { el.setAttribute(a, nv); } catch (e) {} }
  }
}
function fixTree(n){
  if (!n || n.nodeType !== 1) return;
  fixEl(n);
  try {
    var all = n.querySelectorAll("[href],[src],[action],[poster],[srcset]");
    for (var i = 0; i < all.length; i++) fixEl(all[i]);
  } catch (e) {}
}
try {
  new MutationObserver(function(muts){
    for (var i = 0; i < muts.length; i++) {
      var m = muts[i];
      if (m.type === "attributes") { fixEl(m.target); }
      else { for (var j = 0; j < m.addedNodes.length; j++) fixTree(m.addedNodes[j]); }
    }
  }).observe(document.documentElement, { childList: true, subtree: true, attributes: true, attributeFilter: ATTRS });
} catch (e) {}
})();</script>`;
}

/** Full HTML rewrite pipeline. */
export function rewriteHtml(html: string, ctx: RewriteContext): string {
  html = stripSecurityMarkup(html);
  html = rewriteUrlAttributes(html, ctx);
  html = rewriteSrcset(html, ctx);
  html = rewriteStyleAttrs(html, ctx);
  html = html.replace(/<style([^>]*)>([\s\S]*?)<\/style>/gi, (match, attrs: string, css: string) => {
    return `<style${attrs}>${rewriteCss(css, ctx)}</style>`;
  });

  const shim = buildClientShim(ctx);
  if (/<\/head>/i.test(html)) {
    html = html.replace(/<\/head>/i, shim + "</head>");
  } else if (/<body[^>]*>/i.test(html)) {
    html = html.replace(/(<body[^>]*>)/i, "$1" + shim);
  } else {
    html = shim + html;
  }
  return html;
}

/** Rewrite an HLS playlist so segment + key URIs flow through the proxy. */
export function rewriteM3u8(text: string, ctx: RewriteContext): string {
  return text
    .split(/\r?\n/)
    .map((line) => {
      const t = line.trim();
      if (!t) return line;
      if (t.startsWith("#")) {
        return line.replace(/URI="([^"]+)"/g, (match, uri: string) => {
          const abs = absolutize(uri, ctx.base);
          return abs ? `URI="${ctx.toProxy(abs)}"` : match;
        });
      }
      const abs = absolutize(t, ctx.base);
      return abs ? ctx.toProxy(abs) : t;
    })
    .join("\n");
}
