import BrowserShell from "@/components/BrowserShell";
import { utf8SafeDecode } from "@/lib/proxy-shared";

export const dynamic = "force-dynamic";

export default async function BrowsePage({ params }: { params: { encodedUrl: string } }) {
  let target = "";
  try {
    target = utf8SafeDecode(params.encodedUrl);
    const u = new URL(target);
    if (u.protocol !== "http:" && u.protocol !== "https:") target = "";
  } catch {
    target = "";
  }

  if (!target) {
    return (
      <main className="flex min-h-dvh items-center justify-center bg-zinc-950 text-zinc-400">
        <div className="text-center">
          <p className="text-lg font-medium text-zinc-200">Nothing to browse</p>
          <p className="mt-1 text-sm">This link is invalid or incomplete.</p>
        </div>
      </main>
    );
  }

  return <BrowserShell initialTarget={target} />;
}
