// URL detection + normalization for the calculator's dual-purpose input bar.

const DOMAIN_RE =
  /^(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)*[a-z]{2,24}(?::\d{1,5})?(?:[/?#]\S*)?$/i;
const IPV4_RE = /^\d{1,3}(?:\.\d{1,3}){3}(?::\d{1,5})?(?:[/?#]\S*)?$/;
const LOCALHOST_RE = /^(?:localhost|127\.0\.0\.1)(?::\d{1,5})?(?:[/?#]\S*)?$/i;

/**
 * Heuristic: does this string look like a web address?
 * Matches "url:...", "https://...", "example.com/path", "192.168.1.1:8080/x", "localhost:3000".
 */
export function isUrlLike(raw: string): boolean {
  const s = raw.trim();
  if (!s || /\s/.test(s)) return false;
  if (/^url:/i.test(s)) return true;
  if (/^https?:\/\//i.test(s)) return true;
  return DOMAIN_RE.test(s) || IPV4_RE.test(s) || LOCALHOST_RE.test(s);
}

/**
 * Normalize user input into an absolute URL.
 * - strips a leading "url:" (the explicit secret trigger)
 * - keeps http(s):// as-is
 * - localhost / IPs get a bare protocol (http:// localhost, https:// otherwise)
 * - everything else gets "https://www." prepended (e.g. "reddit.com" -> "https://www.reddit.com")
 */
export function normalizeUrl(raw: string): string {
  let s = raw.trim().replace(/^url:/i, "").trim();
  if (/^https?:\/\//i.test(s)) return s;
  if (LOCALHOST_RE.test(s)) return "http://" + s;
  if (IPV4_RE.test(s)) return "https://" + s;
  return "https://www." + s;
}
