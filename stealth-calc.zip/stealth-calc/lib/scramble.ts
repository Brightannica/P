// Lightweight display scrambler for the browser chrome URL bar.
// Deterministic character substitution (ROT13 for letters, +5 mod 10 for digits):
// the shape of the address stays, but the destination is unreadable to onlookers.

export function scrambleUrl(url: string): string {
  return url.replace(/[a-zA-Z0-9]/g, (ch) => {
    if (ch >= "a" && ch <= "z") return String.fromCharCode(((ch.charCodeAt(0) - 97 + 13) % 26) + 97);
    if (ch >= "A" && ch <= "Z") return String.fromCharCode(((ch.charCodeAt(0) - 65 + 13) % 26) + 65);
    return String((Number(ch) + 5) % 10);
  });
}
