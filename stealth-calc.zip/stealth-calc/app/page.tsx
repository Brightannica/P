"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import { ArrowRight } from "lucide-react";
import { evaluateExpression, formatNumber } from "@/lib/calc";
import { isUrlLike, normalizeUrl } from "@/lib/urls";
import { utf8SafeEncode } from "@/lib/proxy-shared";

type KeyDef = {
  label: string;
  kind: "digit" | "fn" | "op" | "equals";
  wide?: boolean;
  value: string;
  testid: string;
};

const KEYS: KeyDef[][] = [
  [
    { label: "AC", kind: "fn", value: "AC", testid: "key-ac" },
    { label: "+/-", kind: "fn", value: "+/-", testid: "key-sign" },
    { label: "%", kind: "fn", value: "%", testid: "key-percent" },
    { label: "÷", kind: "op", value: "/", testid: "key-divide" },
  ],
  [
    { label: "7", kind: "digit", value: "7", testid: "key-7" },
    { label: "8", kind: "digit", value: "8", testid: "key-8" },
    { label: "9", kind: "digit", value: "9", testid: "key-9" },
    { label: "×", kind: "op", value: "*", testid: "key-multiply" },
  ],
  [
    { label: "4", kind: "digit", value: "4", testid: "key-4" },
    { label: "5", kind: "digit", value: "5", testid: "key-5" },
    { label: "6", kind: "digit", value: "6", testid: "key-6" },
    { label: "-", kind: "op", value: "-", testid: "key-minus" },
  ],
  [
    { label: "1", kind: "digit", value: "1", testid: "key-1" },
    { label: "2", kind: "digit", value: "2", testid: "key-2" },
    { label: "3", kind: "digit", value: "3", testid: "key-3" },
    { label: "+", kind: "op", value: "+", testid: "key-plus" },
  ],
  [
    { label: "0", kind: "digit", value: "0", wide: true, testid: "key-0" },
    { label: ".", kind: "digit", value: ".", testid: "key-dot" },
    { label: "=", kind: "equals", value: "=", testid: "key-equals" },
  ],
];

export default function CalculatorPage() {
  const router = useRouter();
  const [expr, setExpr] = useState("");
  const [result, setResult] = useState<string | null>(null);
  const [memory, setMemory] = useState<number | null>(null);
  const [flashError, setFlashError] = useState(false);
  const equalsCount = useRef(0);

  const urlLike = isUrlLike(expr);
  const preview = urlLike ? null : evaluateExpression(expr).ok ? formatNumber(evaluateExpression(expr).value!) : null;

  const navigateToUrl = useCallback(
    (raw: string) => {
      const target = normalizeUrl(raw);
      router.push(`/browse/${utf8SafeEncode(target)}`);
    },
    [router],
  );

  const pressEquals = useCallback(() => {
    const trimmed = expr.trim();
    if (isUrlLike(trimmed)) {
      navigateToUrl(trimmed);
      return;
    }
    const res = evaluateExpression(trimmed);
    if (res.ok && res.value !== undefined) {
      const formatted = formatNumber(res.value);
      setResult(formatted);
      setExpr(formatted);
      equalsCount.current = 0;
      return;
    }
    setFlashError(true);
    window.setTimeout(() => setFlashError(false), 400);
  }, [expr, navigateToUrl]);

  const append = useCallback((value: string) => {
    setExpr((prev) => prev + value);
  }, []);

  const toggleSign = useCallback(() => {
    setExpr((prev) => {
      const m = prev.match(/(\d+\.?\d*)$/);
      if (!m || m.index === undefined) return prev + "-";
      const num = m[1];
      const before = prev.slice(0, m.index);
      if (before.endsWith("(-") && prev.endsWith(")")) {
        return before.slice(0, -2) + num;
      }
      return before + "(-" + num + ")";
    });
  }, []);

  const currentValue = useCallback((): number | null => {
    const res = evaluateExpression(expr);
    return res.ok && res.value !== undefined ? res.value : null;
  }, [expr]);

  const pressKey = useCallback(
    (value: string) => {
      equalsCount.current = 0;
      switch (value) {
        case "AC":
          setExpr("");
          setResult(null);
          break;
        case "+/-":
          toggleSign();
          break;
        case "=":
          pressEquals();
          break;
        case "MR":
          if (memory !== null) append(formatNumber(memory));
          break;
        case "M+":
          setMemory((m) => (currentValue() ?? 0) + (m ?? 0));
          break;
        case "M-":
          setMemory((m) => (m ?? 0) - (currentValue() ?? 0));
          break;
        case "MC":
          setMemory(null);
          break;
        default:
          append(value);
      }
    },
    [append, currentValue, memory, pressEquals, toggleSign],
  );

  // Keyboard support
  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      const target = e.target as HTMLElement;
      if (target && (target.tagName === "INPUT" || target.tagName === "TEXTAREA")) return;
      const k = e.key;
      if (/^[0-9]$/.test(k)) pressKey(k);
      else if (k === "." || k === "+") pressKey(k);
      else if (k === "-") pressKey(k);
      else if (k === "*") append("*");
      else if (k === "/") {
        e.preventDefault();
        append("/");
      } else if (k === "%") pressKey("%");
      else if (k === "(" || k === ")") append(k);
      else if (k === "Enter" || k === "=") {
        e.preventDefault();
        pressEquals();
      } else if (k === "Escape") pressKey("AC");
      else if (k === "Backspace") setExpr((prev) => prev.slice(0, -1));
      // Letters enable typing a web address straight into the display
      else if (k.length === 1 && /[a-zA-Z]/.test(k)) append(k);
      else if (k.length === 1 && "://?&=".includes(k) && isUrlLike(expr + k)) append(k);
    };
    window.addEventListener("keydown", onKeyDown);
    return () => window.removeEventListener("keydown", onKeyDown);
  }, [append, pressEquals, pressKey, expr]);

  const displaySize =
    expr.length > 18 ? "text-3xl" : expr.length > 11 ? "text-4xl" : "text-5xl sm:text-6xl";

  return (
    <main className="flex min-h-dvh items-center justify-center bg-zinc-950 p-4">
      <div className="flex w-full max-w-sm flex-col gap-3 select-none" data-testid="calculator">
        {/* Display */}
        <div className="px-2 pb-2 pt-10">
          <div className="flex h-5 items-center justify-end gap-2">
            {memory !== null && (
              <span className="text-xs font-medium text-orange-400/80" data-testid="memory-indicator">
                M
              </span>
            )}
            {result && !urlLike && (
              <span className="text-xs text-zinc-500" data-testid="calc-preview">
                = {preview ?? result}
              </span>
            )}
          </div>
          <div className="flex items-end justify-between gap-3">
            <div
              className={`display-digits min-w-0 flex-1 truncate text-right font-light leading-tight tracking-tight ${
                flashError ? "animate-pulse text-red-400" : "text-zinc-100"
              } ${displaySize}`}
              data-testid="calc-display"
              aria-live="polite"
            >
              {expr || "0"}
            </div>
            {/* Discreet "Go" affordance: slides open when the input looks like a URL */}
            <button
              onClick={() => urlLike && navigateToUrl(expr)}
              aria-label="Open URL"
              data-testid="button-go"
              className={`go-slide flex h-11 w-11 shrink-0 items-center justify-center rounded-full bg-orange-500 text-white shadow-lg shadow-orange-500/25 hover:bg-orange-400 ${
                urlLike ? "pointer-events-auto opacity-100" : "pointer-events-none w-0 opacity-0"
              }`}
            >
              <ArrowRight className="h-5 w-5" />
            </button>
          </div>
        </div>

        {/* Memory row */}
        <div className="grid grid-cols-4 gap-2 px-1">
          {[
            { label: "MC", value: "MC", testid: "key-mc" },
            { label: "MR", value: "MR", testid: "key-mr" },
            { label: "M+", value: "M+", testid: "key-m-plus" },
            { label: "M-", value: "M-", testid: "key-m-minus" },
          ].map((k) => (
            <button
              key={k.value}
              onClick={() => pressKey(k.value)}
              className="key rounded-xl bg-zinc-800/50 py-2 text-sm font-medium text-zinc-400 hover:bg-zinc-800 hover:text-zinc-200"
              data-testid={k.testid}
            >
              {k.label}
            </button>
          ))}
        </div>

        {/* Keypad */}
        <div className="grid grid-cols-4 gap-3">
          {KEYS.flat().map((k) => (
            <button
              key={k.testid}
              onClick={() => pressKey(k.value)}
              data-testid={k.testid}
              className={`key flex h-16 items-center justify-center rounded-full text-xl font-medium ${
                k.wide ? "col-span-2" : ""
              } ${
                k.kind === "digit"
                  ? "bg-zinc-800/90 text-zinc-100 hover:bg-zinc-700"
                  : k.kind === "fn"
                    ? "bg-zinc-500/25 text-zinc-100 hover:bg-zinc-500/40"
                    : k.kind === "op"
                      ? "bg-orange-500/90 text-white hover:bg-orange-400"
                      : "bg-orange-500 text-white hover:bg-orange-400"
              }`}
            >
              {k.label}
            </button>
          ))}
        </div>
      </div>
    </main>
  );
}
