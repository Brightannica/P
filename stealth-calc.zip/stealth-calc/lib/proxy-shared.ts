// Shared helpers used by both the server (proxy route) and the client (calculator, browser chrome).

function toBinaryString(bytes: Uint8Array): string {
  let bin = "";
  const CHUNK = 0x8000;
  for (let i = 0; i < bytes.length; i += CHUNK) {
    bin += String.fromCharCode.apply(null, Array.from(bytes.subarray(i, i + CHUNK)));
  }
  return bin;
}

/** UTF-8 safe base64url encode (no padding). Works in Node and browsers. */
export function utf8SafeEncode(s: string): string {
  const bytes = new TextEncoder().encode(s);
  return btoa(toBinaryString(bytes)).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
}

/** Decode base64url (with or without padding). */
export function utf8SafeDecode(b64: string): string {
  const norm = b64.replace(/-/g, "+").replace(/_/g, "/");
  const pad = norm.length % 4 ? "=".repeat(4 - (norm.length % 4)) : "";
  const bin = atob(norm + pad);
  const bytes = Uint8Array.from(bin, (c) => c.charCodeAt(0));
  return new TextDecoder().decode(bytes);
}

/** Path prefix for the proxy engine. */
export const PROXY_PREFIX = "/api/proxy/";

/** Build a same-origin proxy URL for an absolute http(s) target. */
export function toProxyUrl(target: string): string {
  return PROXY_PREFIX + utf8SafeEncode(target);
}
